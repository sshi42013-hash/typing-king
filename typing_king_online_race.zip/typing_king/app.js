(() => {
const $ = id => document.getElementById(id);
const prompts = {
 easy: [
  ["ねこ","neko","どうぶつ"],["いぬ","inu","どうぶつ"],["さくら","sakura","しぜん"],["りんご","ringo","たべもの"],["みず","mizu","くらし"],["そら","sora","しぜん"],["すし","sushi","たべもの"],["ともだち","tomodachi","にちじょう"],["おはよう","ohayou","あいさつ"],["ありがとう","arigatou","あいさつ"],["でんしゃ","densha","のりもの"],["はなび","hanabi","イベント"]
 ],
 normal: [
  ["今日はいい天気です","kyouhaiitenkidesu","にちじょう"],["ゲームを楽しもう","geemuwotanoshimou","ゲーム"],["毎日少しずつ練習","mainichisukoshizutsurenshuu","チャレンジ"],["タイピング王を目指す","taipingouowomez asu".replaceAll(" ",""),"チャレンジ"],["好きなことを続けよう","sukinakotowotsuzukeyou","ポジティブ"],["新しい記録に挑戦","atarashiikirokunichousen","チャレンジ"],["笑顔で一日を始める","egaodeichinichio hajimeru".replaceAll(" ",""),"ポジティブ"],["集中して正確に入力","shuuchuushiteseikakunifuuryoku","チャレンジ"],["小さな努力が力になる","chiisanadoryokugachikaraninaru","ポジティブ"],["楽しく学んで成長しよう","tanoshikumanande seichoushiyou".replaceAll(" ",""),"ポジティブ"],["今日の自分を超えていこう","kyounojibunwokoeteikou","チャレンジ"],["速さと正確さを両立","hayasatoseikakusaoryouritsu","チャレンジ"]
 ],
 hard: [
  ["継続は力なり、毎日挑戦しよう","keizoku wa chikaranari mainichichousenshiyou".replaceAll(" ",""),"ことわざ"],["正確な入力とスピードを両立する","seikakunanyuuryokutosupiidoworyouritsusuru","上級"],["失敗を恐れず何度でも挑戦する","shippa i o osorezu nando demo chousensuru".replaceAll(" ",""),"上級"],["集中力を高めて自己ベストを更新","shuuchuuryokuot akamet e jikubesutowokoushin".replaceAll(" ",""),"上級"],["一歩ずつ前進すれば道は開ける","ippozutsu zenshin sureba michi wa hirakeru".replaceAll(" ",""),"ことわざ"],["限界を決めずに可能性を広げよう","genkaiokimezunik anousei o hirogeyou".replaceAll(" ",""),"上級"],["挑戦する気持ちが成長につながる","chousensurukimochigaseichounitsunagaru","上級"],["正しい姿勢でリズムよく入力しよう","tadashiishiseiderizumuyokunyuuryokushiyou","上級"],["積み重ねた努力は必ず結果につながる","tsumikasanetadoryokuwakanarazukekk anitsunagaru".replaceAll(" ",""),"上級"]
 ]
};
const state = {active:false, started:false, time:60, score:0, correct:0, errors:0, combo:0, bestCombo:0, current:null, pos:0, typedChars:0, startedAt:0, sound:true, lastPrompt:-1, locked:false};
let tick = null, audioCtx = null, used = [];
const STORAGE = "typingKingRankingV1";
function beep(freq=600,duration=.06,type="sine",volume=.035){
 if(!state.sound) return;
 try { audioCtx ||= new (window.AudioContext||window.webkitAudioContext)(); if(audioCtx.state==="suspended") audioCtx.resume(); const osc=audioCtx.createOscillator(), gain=audioCtx.createGain(); osc.type=type; osc.frequency.value=freq; gain.gain.value=volume; osc.connect(gain);gain.connect(audioCtx.destination);osc.start();gain.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);osc.stop(audioCtx.currentTime+duration); } catch(e){}
}
function getPool(){return prompts[$("difficulty").value] || prompts.normal}
function pickPrompt(){
 const pool=getPool(); let idx=Math.floor(Math.random()*pool.length);
 if(pool.length>1 && idx===state.lastPrompt) idx=(idx+1)%pool.length;
 state.lastPrompt=idx; state.current=pool[idx]; state.pos=0;
 $("japanesePrompt").textContent=state.current[0]; $("promptCategory").textContent=state.current[2];
 $("promptCount").textContent=`WORD ${state.correct+1}`; $("romajiPrompt").textContent=state.current[1];
 $("progressBar").style.width="0%"; $("typingInput").value="";
}
function renderRomaji(){
 const target=state.current[1], typed=$("typingInput").value.toLowerCase();
 let html="";
 for(let i=0;i<target.length;i++){
   const ch=target[i];
   if(i<typed.length) html+=`<span class="${typed[i]===ch?'typed':'wrong'}">${escapeHtml(ch)}</span>`;
   else html+=`<span>${escapeHtml(ch)}</span>`;
 }
 $("romajiPrompt").innerHTML=html;
 $("progressBar").style.width=Math.min(100,typed.length/target.length*100)+"%";
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function updateMetrics(){
 $("score").textContent=state.score.toLocaleString();
 const total=state.correct+state.errors;
 $("accuracy").innerHTML=(total?Math.round(state.correct/total*100):100)+"<small>%</small>";
 $("wpm").innerHTML=Math.round(state.typedChars/Math.max(1,(60-state.time)/60))+"<small> CPM</small>";
 $("combo").innerHTML=state.combo+"<small> 🔥</small>";
 $("timer").textContent=state.time;
}
function startGame(){
 clearInterval(tick); state.active=true;state.started=true;state.time=60;state.score=0;state.correct=0;state.errors=0;state.combo=0;state.bestCombo=0;state.typedChars=0;state.startedAt=Date.now();state.lastPrompt=-1;state.locked=false;
 $("resultModal").classList.add("hidden");$("startBtn").textContent="↻ リスタート";$("statusMessage").textContent="いい調子！正確に入力しよう。";
 $("typingInput").disabled=false;pickPrompt();updateMetrics();$("typingInput").focus();beep(740,.12,"triangle",.05);
 tick=setInterval(()=>{state.time--;updateMetrics();if(state.time<=10 && state.time>0)beep(440,.05,"sine",.025);if(state.time<=0)finishGame()},1000);
}
function onInput(){
 if(!state.active||!state.current)return;
 let val=$("typingInput").value.toLowerCase().replace(/\s/g,"");
 const target=state.current[1];
 if(val.length>target.length){$("typingInput").value=val.slice(0,target.length);val=$("typingInput").value}
 renderRomaji();
 let correctPrefix=true;
 for(let i=0;i<val.length;i++){if(val[i]!==target[i]){correctPrefix=false;break}}
 if(!correctPrefix){
   state.errors++;state.combo=0;beep(180,.09,"sawtooth",.025);
   $("statusMessage").textContent="おっと！文字を確認してみよう。";
   // Keep the input editable; allow backspace correction.
   updateMetrics();return;
 }
 if(val.length>state.pos){const added=val.length-state.pos;state.typedChars+=added;state.pos=val.length;beep(620+Math.min(300,state.combo*8),.035,"sine",.018)}
 if(val===target){
   state.correct++;state.combo++;state.bestCombo=Math.max(state.bestCombo,state.combo);
   state.score+=Math.max(10,target.length*10)+Math.min(state.combo*2,40);
   beep(900,.08,"triangle",.04);$("statusMessage").textContent="ナイス！その調子！";
   updateMetrics();pickPrompt();
 }
 updateMetrics();
}
function finishGame(){
 if(!state.active)return;state.active=false;clearInterval(tick);$("typingInput").disabled=true;$("startBtn").textContent="▶ もう一度プレイ";
 $("statusMessage").textContent="チャレンジ終了！おつかれさま！";beep(330,.16,"triangle",.04);setTimeout(()=>beep(660,.22,"triangle",.04),120);
 const total=state.correct+state.errors,acc=total?Math.round(state.correct/total*100):100;
 $("finalScore").textContent=state.score.toLocaleString();$("finalAccuracy").textContent=acc+"%";$("finalWpm").textContent=Math.round(state.typedChars/Math.max(1,(60-state.time)/60))+" CPM";
 $("resultSubtitle").textContent=state.score>0?"いい記録！ランキングに保存しよう。":"次はもっとスコアを伸ばしてみよう！";
 $("playerName").value=localStorage.getItem("typingKingName")||"";$("resultModal").classList.remove("hidden");$("playerName").focus();
}
function loadRanking(){try{const x=JSON.parse(localStorage.getItem(STORAGE)||"[]");return Array.isArray(x)?x:[]}catch(e){return[]}}
function renderRanking(){
 const list=loadRanking().sort((a,b)=>b.score-a.score).slice(0,10), root=$("rankingList");root.innerHTML="";
 if(!list.length){root.innerHTML='<div class="empty-ranking">🏁 まだ記録がありません。最初の王者を目指そう！</div>';return}
 list.forEach((r,i)=>{const el=document.createElement("div");el.className="ranking-row";const medal=i===0?"🥇":i===1?"🥈":i===2?"🥉":String(i+1);el.innerHTML=`<div class="rank-num">${medal}</div><div><div class="rank-name">${escapeHtml(r.name)}</div><div class="rank-detail">${escapeHtml(r.difficulty)} · 正確率 ${r.accuracy}% · ${escapeHtml(r.date)}</div></div><div class="rank-score">${r.score.toLocaleString()} pt</div>`;root.appendChild(el)})
}
function saveResult(){
 const name=$("playerName").value.trim().slice(0,16)||"タイピング王";
 localStorage.setItem("typingKingName",name);
 const diff={easy:"初級",normal:"中級",hard:"上級"}[$("difficulty").value];
 const total=state.correct+state.errors,accuracy=total?Math.round(state.correct/total*100):100;
 const list=loadRanking();list.push({name,score:state.score,accuracy,difficulty:diff,date:new Date().toLocaleDateString("ja-JP")});
 list.sort((a,b)=>b.score-a.score);localStorage.setItem(STORAGE,JSON.stringify(list.slice(0,50)));
 $("resultModal").classList.add("hidden");renderRanking();document.getElementById("ranking").scrollIntoView({behavior:"smooth"});beep(800,.1,"triangle",.04);
}
$("startBtn").addEventListener("click",startGame);
$("typingInput").addEventListener("input",onInput);
$("typingInput").addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();if(state.active){pickPrompt();beep(520,.05)}}});
$("difficulty").addEventListener("change",()=>{if(state.active)startGame();else {state.lastPrompt=-1;pickPrompt();$("typingInput").disabled=true}});
$("soundToggle").addEventListener("click",()=>{state.sound=!state.sound;$("soundToggle").textContent=state.sound?"🔊 サウンド ON":"🔇 サウンド OFF";$("soundToggle").setAttribute("aria-pressed",String(state.sound));if(state.sound)beep(720,.08)});
$("saveResult").addEventListener("click",saveResult);
$("retryBtn").addEventListener("click",startGame);
$("clearRanking").addEventListener("click",()=>{if(confirm("この端末のランキング履歴をすべて消去しますか？")){localStorage.removeItem(STORAGE);renderRanking()}});
document.addEventListener("visibilitychange",()=>{if(document.hidden&&state.active){clearInterval(tick);state.active=false;$("typingInput").disabled=true;$("statusMessage").textContent="画面を離れたためゲームを停止しました。スタートして再挑戦してください。";$("startBtn").textContent="▶ スタート"}});
pickPrompt();updateMetrics();renderRanking();
})();