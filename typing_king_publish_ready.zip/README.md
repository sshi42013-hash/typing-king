# タイピング王 — GitHub Pages公開用ファイル

## GitHub Pagesへの公開

このZIPは、公開に必要なファイルをリポジトリのルートへ直接アップロードできる構成です。

1. ZIPを展開します。
2. GitHubの `typing-king` リポジトリを開き、`main` ブランチのトップ画面に移動します。
3. `Add file` → `Upload files` を選び、ZIPの中のファイル5つ（`index.html`, `style.css`, `app.js`, `race.js`, `README.md`）をアップロードします。ZIP自体ではなく、展開した中身を選んでください。
4. `Commit changes` を押して `main` に保存します。
5. Settings → Pages で Source が `Deploy from a branch`、Branch が `main`、Folder が `/(root)` になっていることを確認します。
6. 1〜5分待ち、Pages画面に表示された公開URLを開きます。

## 含まれる機能
- 60秒タイピングチャレンジ
- 難易度設定、スコア、正確率、CPM、コンボ
- このブラウザ内に保存するランキング
- Supabase設定後に利用できるオンライン対戦UI

## オンライン対戦について
`race.js` 内の `PASTE_SUPABASE_PROJECT_URL_HERE` と `PASTE_SUPABASE_ANON_KEY_HERE` を、自分のSupabaseプロジェクトのURLと公開用 anon/publishable keyに設定する必要があります。設定しない場合、オンライン対戦は利用できません。秘密の service_role key は絶対に公開しないでください。

## ランキングについて
現状のランキングは同じブラウザ内のローカル保存です。全ユーザー共通のオンラインランキングではありません。
